﻿CREATE DATABASE studentDb;
GO
USE studentDb;
GO

CREATE TABLE loginTab (
    id INT PRIMARY KEY IDENTITY(1,1),
    Username NVARCHAR(50),
    Password NVARCHAR(50),
    Role NVARCHAR(20)
);



CREATE TABLE Students (
    StudentID INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(100) NOT NULL,
    ClassName NVARCHAR(50) NOT NULL,
    DateOfBirth DATE NOT NULL,
    Gender NVARCHAR(10) NOT NULL,
    PhoneNumber NVARCHAR(15) NOT NULL,
    Email NVARCHAR(100) NOT NULL
);

CREATE TABLE teacher (
    id INT IDENTITY(1,1) PRIMARY KEY,
    tenGV NVARCHAR(100) NOT NULL,
    sdt NVARCHAR(15),
    email NVARCHAR(100),
    diachi NVARCHAR(255)
);

CREATE TABLE Classes (
    ClassID INT IDENTITY(1,1) PRIMARY KEY,
    ClassName NVARCHAR(50) NOT NULL,
    TeacherID INT, -- Giáo viên chủ nhiệm (optional)
    Description NVARCHAR(255),
    FOREIGN KEY (TeacherID) REFERENCES teacher(id)
);

CREATE TABLE Subjects (
    SubjectID INT IDENTITY(1,1) PRIMARY KEY,
    SubjectName NVARCHAR(100) NOT NULL
);

CREATE TABLE ClassSubject (
    ClassID INT,
    SubjectID INT,
    TeacherID INT,
    PRIMARY KEY (ClassID, SubjectID),
    FOREIGN KEY (ClassID) REFERENCES Classes(ClassID),
    FOREIGN KEY (SubjectID) REFERENCES Subjects(SubjectID),
    FOREIGN KEY (TeacherID) REFERENCES teacher(id)
);

CREATE TABLE Homework (
    HomeworkID INT IDENTITY(1,1) PRIMARY KEY,
    ClassID INT NOT NULL,
    SubjectID INT NOT NULL,
    TeacherID INT NOT NULL,
    Title NVARCHAR(255) NOT NULL,
    Description NVARCHAR(MAX),
    AssignDate DATE NOT NULL DEFAULT GETDATE(),
    DueDate DATE NOT NULL,

    FOREIGN KEY (ClassID) REFERENCES Classes(ClassID),
    FOREIGN KEY (SubjectID) REFERENCES Subjects(SubjectID),
    FOREIGN KEY (TeacherID) REFERENCES teacher(id)
);

ALTER TABLE Students
ADD ClassID INT;

ALTER TABLE Students
ADD CONSTRAINT FK_Students_ClassID FOREIGN KEY (ClassID) REFERENCES Classes(ClassID);
--
INSERT INTO teacher (tenGV, sdt, email, diachi) VALUES
(N'Nguyễn Văn A', '0912345678', 'nguyenvana@example.com', N'Hà Nội'),
(N'Lê Thị B', '0987654321', 'lethib@example.com', N'TP.HCM'),
(N'Phạm Văn C', '0934567890', 'phamvanc@example.com', N'Đà Nẵng');

INSERT INTO Classes (ClassName, TeacherID, Description) VALUES
(N'10A1', 6, N'Lớp chuyên Toán'),
(N'10A2', 7, N'Lớp chuyên Văn'),
(N'11B1', 8, N'Lớp chọn');

INSERT INTO Subjects (SubjectName) VALUES
(N'Toán'),
(N'Văn'),
(N'Lý'),
(N'Hóa'),
(N'Anh Văn');

INSERT INTO ClassSubject (ClassID, SubjectID, TeacherID) VALUES
(4, 1, 8),  -- 10A1 học Toán do thầy A dạy
(5, 3, 9),  -- 10A1 học Lý do thầy C dạy
(4, 2, 6),  -- 10A2 học Văn do cô B dạy
(6, 1, 7),  -- 11B1 học Toán do thầy A dạy
(6, 5, 8);  -- 11B1 học Anh Văn do cô B dạy

INSERT INTO Students (FullName, ClassName, DateOfBirth, Gender, PhoneNumber, Email, ClassID) VALUES
(N'Trần Minh Huy', N'10A1', '2008-05-10', N'Nam', '0911111111', 'huytm@example.com', 4),
(N'Nguyễn Thị Lan', N'10A1', '2008-07-15', N'Nữ', '0922222222', 'lannt@example.com', 5),
(N'Lê Văn An', N'10A2', '2008-03-22', N'Nam', '0933333333', 'anlv@example.com', 6),
(N'Phạm Thảo Vy', N'11B1', '2007-11-30', N'Nữ', '0944444444', 'vypt@example.com', 4);
(N'Hoàng Minh Nhật', N'10A3', '2008-02-10', N'Nam', '0901000001', 'nhathm1@example.com', 4),
(N'Vũ Thị Mai', N'10A3', '2008-06-11', N'Nữ', '0901000002', 'maivt2@example.com', 5),
(N'Nguyễn Hữu Đạt', N'10A3', '2008-01-05', N'Nam', '0901000003', 'datnh3@example.com', 6),
(N'Trần Thị Hồng', N'10A3', '2008-08-18', N'Nữ', '0901000004', 'hongtt4@example.com', 4),
(N'Đỗ Thanh Tùng', N'10A3', '2008-12-23', N'Nam', '0901000005', 'tungdt5@example.com', 5),
(N'Phan Thị Yến', N'10A3', '2008-07-29', N'Nữ', '0901000006', 'yenpt6@example.com', 6),
(N'Tô Minh Khôi', N'10A3', '2008-10-10', N'Nam', '0901000007', 'khoitm7@example.com', 4),
(N'Lê Thị Phương', N'10A3', '2008-03-12', N'Nữ', '0901000008', 'phuonglt8@example.com', 5),
(N'Ngô Văn Sơn', N'10A3', '2008-05-19', N'Nam', '0901000009', 'sonnv9@example.com', 6),
(N'Hồ Thị Hằng', N'10A3', '2008-09-25', N'Nữ', '0901000010', 'hanght10@example.com', 4),

(N'Bùi Hữu Phúc', N'10A3', '2008-04-01', N'Nam', '0901000011', 'phucbh11@example.com', 5),
(N'Nguyễn Thị Ngọc', N'10A3', '2008-08-03', N'Nữ', '0901000012', 'ngocnt12@example.com', 6),
(N'Trịnh Văn Bảo', N'10A3', '2008-07-06', N'Nam', '0901000013', 'baotv13@example.com', 4),
(N'Đặng Thị Quyên', N'10A3', '2008-06-22', N'Nữ', '0901000014', 'quyendt14@example.com', 5),
(N'Huỳnh Văn Cường', N'10A3', '2008-02-27', N'Nam', '0901000015', 'cuonghv15@example.com', 6),
(N'Nguyễn Mai Anh', N'10A3', '2008-03-15', N'Nữ', '0901000016', 'anhnm16@example.com', 4),
(N'Trương Quốc Toàn', N'10A3', '2008-10-02', N'Nam', '0901000017', 'toantq17@example.com', 5),
(N'Phạm Thị Tuyết', N'10A3', '2008-11-07', N'Nữ', '0901000018', 'tuyetpt18@example.com', 6),
(N'Lý Gia Bảo', N'10A3', '2008-01-21', N'Nam', '0901000019', 'baolg19@example.com', 4),
(N'Đinh Thị Nhàn', N'10A3', '2008-09-11', N'Nữ', '0901000020', 'nhandt20@example.com', 5),

(N'Nguyễn Minh Hưng', N'10A3', '2008-06-30', N'Nam', '0901000021', 'hungnm21@example.com', 6),
(N'Hoàng Thị Thảo', N'10A3', '2008-04-20', N'Nữ', '0901000022', 'thaoth22@example.com', 4),
(N'Võ Đức Lộc', N'10A3', '2008-05-14', N'Nam', '0901000023', 'locvd23@example.com', 5),
(N'Lê Thị Kim', N'10A3', '2008-07-01', N'Nữ', '0901000024', 'kimlt24@example.com', 6),
(N'Trần Văn Tú', N'10A3', '2008-08-09', N'Nam', '0901000025', 'tutv25@example.com', 4),
(N'Ngô Thị Dung', N'10A3', '2008-03-19', N'Nữ', '0901000026', 'dungnt26@example.com', 5),
(N'Bùi Quốc Trung', N'10A3', '2008-01-30', N'Nam', '0901000027', 'trungbq27@example.com', 6),
(N'Phạm Thị Hà', N'10A3', '2008-10-28', N'Nữ', '0901000028', 'hapt28@example.com', 4),
(N'Tạ Đức Hùng', N'10A3', '2008-11-15', N'Nam', '0901000029', 'hungtd29@example.com', 5),
(N'Đoàn Thị Nga', N'10A3', '2008-12-01', N'Nữ', '0901000030', 'ngadt30@example.com', 6);


INSERT INTO Homework (ClassID, SubjectID, TeacherID, Title, Description, AssignDate, DueDate) VALUES
(4, 1, 6, N'Bài tập hàm số', N'Làm các bài 1-5 trang 45 SGK Toán', '2025-04-20', '2025-04-27'),
(5, 2, 7, N'Phân tích bài thơ', N'Phân tích đoạn thơ trong bài Tây Tiến', '2025-04-21', '2025-04-28'),
(4, 5, 6, N'Từ vựng Unit 3', N'Học 20 từ mới trong Unit 3 SGK Anh Văn', '2025-04-22', '2025-04-29');



--
-- Optional: xóa ClassName nếu không cần nữa
-- ALTER TABLE Students DROP COLUMN ClassName;
SELECT * FROM Classes;


-- Các câu lệnh SELECT, INSERT, UPDATE, DELETE cho bảng Students
SELECT * FROM ClassSubject;

INSERT INTO Students (FullName, ClassName, DateOfBirth, Gender, PhoneNumber, Email)
VALUES (@FullName, @ClassName, @DOB, @Gender, @Phone, @Email);

INSERT INTO Students (FullName, ClassName, DateOfBirth, Gender, PhoneNumber, Email) VALUES
(N'Nguyễn Văn A', N'12A1', '2006-05-15', N'Nam', '0912345678', 'nguyenvana@example.com'),
(N'Trần Thị B', N'11B2', '2007-08-20', N'Nữ', '0987654321', 'tranthib@example.com'),
(N'Lê Văn C', N'10C3', '2008-12-05', N'Nam', '0901234567', 'levanc@example.com'),
(N'Phạm Thị D', N'12A2', '2006-11-30', N'Nữ', '0978123456', 'phamthid@example.com'),
(N'Hoàng Văn E', N'11B1', '2007-07-10', N'Nam', '0932123456', 'hoangvane@example.com');


UPDATE Students
SET FullName = @FullName, ClassName = @ClassName, DateOfBirth = @DOB, Gender = @Gender, 
    PhoneNumber = @Phone, Email = @Email
WHERE StudentID = @ID;

DELETE FROM Students WHERE StudentID = @ID;

SELECT * FROM Students WHERE FullName LIKE @keyword;

-- Các câu lệnh SELECT, INSERT, UPDATE, DELETE cho bảng teacher
SELECT id, tenGV, sdt, email, diachi FROM teacher;

INSERT INTO teacher (tenGV, sdt, email, diachi)
VALUES (@ten, @sdt, @email, @diachi);

INSERT INTO teacher (tenGV, sdt, email, diachi) VALUES
(N'Nguyễn Thị Hoa', '0911122233', 'hoant@example.com', N'123 Đường Lê Lợi, Quận 1, TP.HCM'),
(N'Trần Văn Nam', '0922233344', 'namtv@example.com', N'456 Đường Trần Hưng Đạo, Quận 5, TP.HCM'),
(N'Lê Thị Hồng', '0933344455', 'honglt@example.com', N'789 Đường Nguyễn Trãi, Quận 10, TP.HCM'),
(N'Phạm Văn Cường', '0944455566', 'cuongpv@example.com', N'321 Đường Cách Mạng Tháng 8, Quận 3, TP.HCM'),
(N'Đỗ Thị Yến', '0955566677', 'yendt@example.com', N'654 Đường Nguyễn Văn Cừ, Quận 7, TP.HCM');


UPDATE teacher
SET tenGV = @ten, sdt = @sdt, email = @email, diachi = @diachi
WHERE id = @id;

DELETE FROM teacher WHERE id = @id;

-- Câu lệnh INSERT vào bảng loginTab ( đã có bảng admin_account)
INSERT INTO loginTab (Username, Password, Role)
VALUES ('admin', 'admin', 'admin');
INSERT INTO loginTab (Username, Password, Role)
VALUES ('teacher1', 'teacher1', 'teacher');

-- Các câu lệnh SELECT cho loginTab và admin_account
SELECT Role FROM loginTab WHERE Username = @username AND Password = @password;

SELECT * FROM admin_account;

INSERT INTO admin_account (username, password, role)
VALUES (@username, @password, @role);

UPDATE admin_account 
SET username = @username, password = @password, role = @role
WHERE id = @id;

DELETE FROM admin_account WHERE id = @id;
