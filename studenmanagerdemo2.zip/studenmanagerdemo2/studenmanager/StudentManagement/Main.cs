﻿using System;
using System.Windows.Forms;

namespace StudentManagement
{
    public partial class Main : Form
    {
        private string currentRole;
        private string currentUsername;

        public Main(string role, string username)
        {
            InitializeComponent();
            currentRole = role;
            currentUsername = username;
        }

        private void Main_Load(object sender, EventArgs e)
        {
            // Phân quyền dựa trên role
            if (currentRole == "admin")
            {
                // Admin có thể truy cập tất cả các nút
                button1.Enabled = true;  // Student
                button2.Enabled = true;  // Class
                button3.Enabled = true;  // Teacher
                button4.Enabled = true;  // Admin
                button5.Enabled = true;  // Notification
                button7.Enabled = true;  // Dashboard
            }
            else if (currentRole == "teacher")
            {
                // Teacher không thể truy cập Admin
                button1.Enabled = true;  // Student
                button2.Enabled = true;  // Class
                button3.Enabled = false;  // Teacher
                button4.Enabled = false; // Admin
                button5.Enabled = true;  // Notification
                button7.Enabled = true;  // Dashboard
            }
            MessageBox.Show("Role hiện tại: " + currentRole);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
            studentForm.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Class studentForm = new Class();
            studentForm.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (currentRole == "admin")
            {
                Teacher teacherForm = new Teacher(); 
                teacherForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("🚫 Bạn không có quyền truy cập vào Teacher!");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (currentRole == "admin")
            {
                Admin Admin = new Admin(currentUsername);
                Admin.ShowDialog();
            }
            else
            {
                MessageBox.Show("🚫 Bạn không có quyền truy cập vào Admin!");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Điều hướng tới Notification Form");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Điều hướng tới Dashboard Form");
        }
        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
