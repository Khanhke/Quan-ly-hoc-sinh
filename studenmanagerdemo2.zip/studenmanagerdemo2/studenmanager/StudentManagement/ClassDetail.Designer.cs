﻿namespace StudentManagement
{
    partial class ClassDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label7 = new Label();
            label1 = new Label();
            groupBox3 = new GroupBox();
            lvStudentsInClass = new ListView();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            columnHeader4 = new ColumnHeader();
            columnHeader5 = new ColumnHeader();
            columnHeader6 = new ColumnHeader();
            btnAssignHomework = new Button();
            label2 = new Label();
            txtClass = new TextBox();
            txtTeacher = new TextBox();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ControlText;
            label7.Location = new Point(51, 134);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(216, 24);
            label7.TabIndex = 1;
            label7.Text = "Giáo viên chủ nhiệm";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ControlText;
            label1.Location = new Point(51, 84);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(89, 24);
            label1.TabIndex = 2;
            label1.Text = "Tên Lớp";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(lvStudentsInClass);
            groupBox3.ForeColor = SystemColors.Highlight;
            groupBox3.Location = new Point(51, 215);
            groupBox3.Margin = new Padding(4, 5, 4, 5);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new Padding(4, 5, 4, 5);
            groupBox3.Size = new Size(1042, 442);
            groupBox3.TabIndex = 41;
            groupBox3.TabStop = false;
            groupBox3.Text = "Thông tin học sinh";
            // 
            // lvStudentsInClass
            // 
            lvStudentsInClass.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2, columnHeader3, columnHeader4, columnHeader5, columnHeader6 });
            lvStudentsInClass.FullRowSelect = true;
            lvStudentsInClass.GridLines = true;
            lvStudentsInClass.Location = new Point(9, 31);
            lvStudentsInClass.Margin = new Padding(4, 5, 4, 5);
            lvStudentsInClass.Name = "lvStudentsInClass";
            lvStudentsInClass.Size = new Size(1025, 401);
            lvStudentsInClass.TabIndex = 12;
            lvStudentsInClass.UseCompatibleStateImageBehavior = false;
            lvStudentsInClass.View = View.Details;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "FullName";
            columnHeader1.Width = 250;
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "ClassName";
            columnHeader2.Width = 100;
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "DateOfBirth";
            columnHeader3.Width = 150;
            // 
            // columnHeader4
            // 
            columnHeader4.Text = "Gender";
            columnHeader4.Width = 100;
            // 
            // columnHeader5
            // 
            columnHeader5.Text = "PhoneNumber";
            columnHeader5.Width = 200;
            // 
            // columnHeader6
            // 
            columnHeader6.Text = "Email";
            columnHeader6.Width = 250;
            // 
            // btnAssignHomework
            // 
            btnAssignHomework.Location = new Point(838, 110);
            btnAssignHomework.Name = "btnAssignHomework";
            btnAssignHomework.Size = new Size(247, 77);
            btnAssignHomework.TabIndex = 42;
            btnAssignHomework.Text = "Giao Bài tập";
            btnAssignHomework.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Tahoma", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.MenuHighlight;
            label2.Location = new Point(51, 9);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(383, 48);
            label2.TabIndex = 43;
            label2.Text = "Thông tin Lớp học";
            // 
            // txtClass
            // 
            txtClass.Location = new Point(266, 85);
            txtClass.Name = "txtClass";
            txtClass.Size = new Size(103, 27);
            txtClass.TabIndex = 44;
            // 
            // txtTeacher
            // 
            txtTeacher.Location = new Point(285, 131);
            txtTeacher.Name = "txtTeacher";
            txtTeacher.Size = new Size(299, 27);
            txtTeacher.TabIndex = 45;
            // 
            // ClassDetail
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1153, 671);
            Controls.Add(txtTeacher);
            Controls.Add(txtClass);
            Controls.Add(label2);
            Controls.Add(btnAssignHomework);
            Controls.Add(groupBox3);
            Controls.Add(label1);
            Controls.Add(label7);
            Name = "ClassDetail";
            Text = "ClassDetail";
            groupBox3.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
            //
            this.Load += new System.EventHandler(this.ClassDetail_Load);
            btnAssignHomework.Click += new System.EventHandler(this.btnAssignHomework_Click);

        }

        #endregion

        private Label label7;
        private Label label1;
        private GroupBox groupBox3;
        private ListView lvStudentsInClass;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
        private ColumnHeader columnHeader5;
        private ColumnHeader columnHeader6;
        private Button btnAssignHomework;
        private Label label2;
        private TextBox txtClass;
        private TextBox txtTeacher;
    }
}