﻿namespace StudentManagement
{
    partial class Teacher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox3 = new GroupBox();
            lsvGiaoVien = new ListView();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            columnHeader4 = new ColumnHeader();
            columnHeader5 = new ColumnHeader();
            label1 = new Label();
            groupBox2 = new GroupBox();
            txtEmail = new TextBox();
            label5 = new Label();
            txtdiachi = new TextBox();
            txtidGv = new TextBox();
            label4 = new Label();
            txtsdt = new TextBox();
            txttenGv = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label7 = new Label();
            groupBox1 = new GroupBox();
            btnThoat = new Button();
            btnHuy = new Button();
            btnSua = new Button();
            btnXoa = new Button();
            btnLuu = new Button();
            btnThem = new Button();
            groupBox3.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(lsvGiaoVien);
            groupBox3.ForeColor = SystemColors.Highlight;
            groupBox3.Location = new Point(41, 423);
            groupBox3.Margin = new Padding(4, 5, 4, 5);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new Padding(4, 5, 4, 5);
            groupBox3.Size = new Size(835, 360);
            groupBox3.TabIndex = 40;
            groupBox3.TabStop = false;
            groupBox3.Text = "Thông tin Giáo Viên";
            // 
            // lsvGiaoVien
            // 
            lsvGiaoVien.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2, columnHeader3, columnHeader4, columnHeader5 });
            lsvGiaoVien.FullRowSelect = true;
            lsvGiaoVien.GridLines = true;
            lsvGiaoVien.Location = new Point(9, 31);
            lsvGiaoVien.Margin = new Padding(4, 5, 4, 5);
            lsvGiaoVien.Name = "lsvGiaoVien";
            lsvGiaoVien.Size = new Size(816, 318);
            lsvGiaoVien.TabIndex = 12;
            lsvGiaoVien.UseCompatibleStateImageBehavior = false;
            lsvGiaoVien.View = View.Details;
            lsvGiaoVien.SelectedIndexChanged += LsvGiaoVien_SelectedIndexChanged;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "MaGV";
            columnHeader1.Width = 49;
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "Tên Giáo Viên";
            columnHeader2.Width = 141;
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "Số Điện Thoại";
            columnHeader3.Width = 105;
            // 
            // columnHeader4
            // 
            columnHeader4.Text = "Email";
            columnHeader4.Width = 159;
            // 
            // columnHeader5
            // 
            columnHeader5.Text = "Địa chỉ";
            columnHeader5.Width = 257;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Tahoma", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.MenuHighlight;
            label1.Location = new Point(233, 19);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(389, 48);
            label1.TabIndex = 39;
            label1.Text = "Quản Lý Giáo Viên";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(txtEmail);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(txtdiachi);
            groupBox2.Controls.Add(txtidGv);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(txtsdt);
            groupBox2.Controls.Add(txttenGv);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(label7);
            groupBox2.ForeColor = SystemColors.Highlight;
            groupBox2.Location = new Point(54, 102);
            groupBox2.Margin = new Padding(4, 5, 4, 5);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(4, 5, 4, 5);
            groupBox2.Size = new Size(821, 200);
            groupBox2.TabIndex = 38;
            groupBox2.TabStop = false;
            groupBox2.Text = "Thông tin chi tiết";
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(215, 142);
            txtEmail.Margin = new Padding(4, 5, 4, 5);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(185, 27);
            txtEmail.TabIndex = 3;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.ControlText;
            label5.Location = new Point(9, 147);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(65, 24);
            label5.TabIndex = 15;
            label5.Text = "Email";
            // 
            // txtdiachi
            // 
            txtdiachi.Location = new Point(577, 91);
            txtdiachi.Margin = new Padding(4, 5, 4, 5);
            txtdiachi.Name = "txtdiachi";
            txtdiachi.Size = new Size(188, 27);
            txtdiachi.TabIndex = 5;
            // 
            // txtidGv
            // 
            txtidGv.Location = new Point(215, 22);
            txtidGv.Margin = new Padding(4, 5, 4, 5);
            txtidGv.Name = "txtidGv";
            txtidGv.Size = new Size(185, 27);
            txtidGv.TabIndex = 1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ControlText;
            label4.Location = new Point(485, 88);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(79, 24);
            label4.TabIndex = 9;
            label4.Text = "Địa chỉ";
            // 
            // txtsdt
            // 
            txtsdt.Location = new Point(580, 22);
            txtsdt.Margin = new Padding(4, 5, 4, 5);
            txtsdt.Name = "txtsdt";
            txtsdt.Size = new Size(185, 27);
            txtsdt.TabIndex = 4;
            // 
            // txttenGv
            // 
            txttenGv.Location = new Point(215, 85);
            txttenGv.Margin = new Padding(4, 5, 4, 5);
            txttenGv.Name = "txttenGv";
            txttenGv.Size = new Size(185, 27);
            txttenGv.TabIndex = 2;
            txttenGv.TextChanged += txttenGv_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ControlText;
            label3.Location = new Point(410, 27);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(148, 24);
            label3.TabIndex = 5;
            label3.Text = "Số Điện Thoại";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ControlText;
            label2.Location = new Point(9, 83);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(149, 24);
            label2.TabIndex = 4;
            label2.Text = "Tên Giáo Viên";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ControlText;
            label7.Location = new Point(9, 27);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(142, 24);
            label7.TabIndex = 0;
            label7.Text = "Mã Giáo Viên";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnThoat);
            groupBox1.Controls.Add(btnHuy);
            groupBox1.Controls.Add(btnSua);
            groupBox1.Controls.Add(btnXoa);
            groupBox1.Controls.Add(btnLuu);
            groupBox1.Controls.Add(btnThem);
            groupBox1.Location = new Point(54, 312);
            groupBox1.Margin = new Padding(4, 5, 4, 5);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4, 5, 4, 5);
            groupBox1.Size = new Size(821, 102);
            groupBox1.TabIndex = 37;
            groupBox1.TabStop = false;
            // 
            // btnThoat
            // 
            btnThoat.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnThoat.ForeColor = SystemColors.InactiveCaptionText;
            btnThoat.Location = new Point(679, 29);
            btnThoat.Margin = new Padding(4, 5, 4, 5);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(127, 60);
            btnThoat.TabIndex = 11;
            btnThoat.Text = "Thoát";
            btnThoat.UseVisualStyleBackColor = true;

            // 
            // btnHuy
            // 
            btnHuy.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnHuy.ForeColor = SystemColors.InactiveCaptionText;
            btnHuy.Location = new Point(544, 29);
            btnHuy.Margin = new Padding(4, 5, 4, 5);
            btnHuy.Name = "btnHuy";
            btnHuy.Size = new Size(127, 60);
            btnHuy.TabIndex = 10;
            btnHuy.Text = "Hủy";
            btnHuy.UseVisualStyleBackColor = true;
            // 
            // btnSua
            // 
            btnSua.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSua.ForeColor = SystemColors.InactiveCaptionText;
            btnSua.Location = new Point(275, 28);
            btnSua.Margin = new Padding(4, 5, 4, 5);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(127, 60);
            btnSua.TabIndex = 8;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            btnXoa.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnXoa.ForeColor = SystemColors.InactiveCaptionText;
            btnXoa.Location = new Point(140, 29);
            btnXoa.Margin = new Padding(4, 5, 4, 5);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(127, 60);
            btnXoa.TabIndex = 7;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = true;
            // 
            // btnLuu
            // 
            btnLuu.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLuu.ForeColor = SystemColors.InactiveCaptionText;
            btnLuu.Location = new Point(409, 28);
            btnLuu.Margin = new Padding(4, 5, 4, 5);
            btnLuu.Name = "btnLuu";
            btnLuu.Size = new Size(127, 60);
            btnLuu.TabIndex = 9;
            btnLuu.Text = "Lưu";
            btnLuu.UseVisualStyleBackColor = true;
            // 
            // btnThem
            // 
            btnThem.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnThem.ForeColor = SystemColors.InactiveCaptionText;
            btnThem.Location = new Point(5, 29);
            btnThem.Margin = new Padding(4, 5, 4, 5);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(127, 60);
            btnThem.TabIndex = 6;
            btnThem.Text = "Thêm";
            btnThem.UseVisualStyleBackColor = true;
            // 
            // Teacher
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(916, 802);
            Controls.Add(groupBox3);
            Controls.Add(label1);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Teacher";
            Text = "Teacher";
            groupBox3.ResumeLayout(false);
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
            //
            btnThem.Click += btnThem_Click;
            btnLuu.Click += btnLuu_Click;
            btnSua.Click += btnSua_Click;
            btnXoa.Click += btnXoa_Click;
            btnHuy.Click += btnHuy_Click;
        }

        private void LsvGiaoVien_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        #endregion

        private GroupBox groupBox3;
        private ListView lsvGiaoVien;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
        private ColumnHeader columnHeader5;
        private Label label1;
        private GroupBox groupBox2;
        private TextBox txtEmail;
        private Label label5;
        private TextBox txtdiachi;
        private TextBox txtidGv;
        private Label label4;
        private TextBox txtsdt;
        private TextBox txttenGv;
        private Label label3;
        private Label label2;
        private Label label7;
        private GroupBox groupBox1;
        private Button btnThoat;
        private Button btnHuy;
        private Button btnSua;
        private Button btnXoa;
        private Button btnLuu;
        private Button btnThem;
    }
}