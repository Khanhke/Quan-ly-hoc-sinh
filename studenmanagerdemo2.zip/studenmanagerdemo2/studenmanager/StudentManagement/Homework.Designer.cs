﻿
namespace StudentManagement
{
    partial class Homework
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            label1 = new Label();
            cboClass = new ComboBox();
            cboSubject = new ComboBox();
            label2 = new Label();
            cboTeacher = new ComboBox();
            label4 = new Label();
            txtTitle = new TextBox();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            dtpAssignDate = new DateTimePicker();
            dtpDueDate = new DateTimePicker();
            rtbDescription = new RichTextBox();
            label8 = new Label();
            btnHuy = new Button();
            btnSua = new Button();
            btnXoa = new Button();
            btnLuu = new Button();
            btnThem = new Button();
            label9 = new Label();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            lvHomeworklist = new ListView();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ControlText;
            label3.Location = new Point(49, 58);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(89, 24);
            label3.TabIndex = 44;
            label3.Text = "Tên Lớp";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ControlText;
            label1.Location = new Point(49, 101);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(97, 24);
            label1.TabIndex = 45;
            label1.Text = "Môn Học";
            // 
            // cboClass
            // 
            cboClass.FormattingEnabled = true;
            cboClass.Location = new Point(196, 59);
            cboClass.Name = "cboClass";
            cboClass.Size = new Size(273, 28);
            cboClass.TabIndex = 46;
            // 
            // cboSubject
            // 
            cboSubject.FormattingEnabled = true;
            cboSubject.Location = new Point(196, 102);
            cboSubject.Name = "cboSubject";
            cboSubject.Size = new Size(273, 28);
            cboSubject.TabIndex = 47;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ControlText;
            label2.Location = new Point(49, 140);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(104, 24);
            label2.TabIndex = 48;
            label2.Text = "Giáo viên";
            // 
            // cboTeacher
            // 
            cboTeacher.FormattingEnabled = true;
            cboTeacher.Location = new Point(196, 141);
            cboTeacher.Name = "cboTeacher";
            cboTeacher.Size = new Size(273, 28);
            cboTeacher.TabIndex = 49;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ControlText;
            label4.Location = new Point(649, 43);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(84, 24);
            label4.TabIndex = 50;
            label4.Text = "Tiêu đề";
            // 
            // txtTitle
            // 
            txtTitle.Location = new Point(740, 44);
            txtTitle.Multiline = true;
            txtTitle.Name = "txtTitle";
            txtTitle.Size = new Size(606, 70);
            txtTitle.TabIndex = 51;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.ControlText;
            label5.Location = new Point(649, 239);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(101, 24);
            label5.TabIndex = 52;
            label5.Text = "Nội dung";
            label5.Click += label5_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.ControlText;
            label6.Location = new Point(649, 135);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(113, 24);
            label6.TabIndex = 53;
            label6.Text = "Ngày Giao";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ControlText;
            label7.Location = new Point(649, 185);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(94, 24);
            label7.TabIndex = 54;
            label7.Text = "Hạn nộp";
            // 
            // dtpAssignDate
            // 
            dtpAssignDate.Location = new Point(769, 137);
            dtpAssignDate.Name = "dtpAssignDate";
            dtpAssignDate.Size = new Size(250, 27);
            dtpAssignDate.TabIndex = 56;
            // 
            // dtpDueDate
            // 
            dtpDueDate.Location = new Point(769, 185);
            dtpDueDate.Name = "dtpDueDate";
            dtpDueDate.Size = new Size(250, 27);
            dtpDueDate.TabIndex = 57;
            // 
            // rtbDescription
            // 
            rtbDescription.Location = new Point(649, 266);
            rtbDescription.Name = "rtbDescription";
            rtbDescription.Size = new Size(697, 485);
            rtbDescription.TabIndex = 58;
            rtbDescription.Text = "";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Tahoma", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.MenuHighlight;
            label8.Location = new Point(-1, -4);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(240, 48);
            label8.TabIndex = 59;
            label8.Text = "Homework";
            // 
            // btnHuy
            // 
            btnHuy.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnHuy.ForeColor = SystemColors.InactiveCaptionText;
            btnHuy.Location = new Point(1219, 759);
            btnHuy.Margin = new Padding(4, 5, 4, 5);
            btnHuy.Name = "btnHuy";
            btnHuy.Size = new Size(127, 60);
            btnHuy.TabIndex = 64;
            btnHuy.Text = "Hủy";
            btnHuy.UseVisualStyleBackColor = true;
            btnHuy.Click += btnHuy_Click;
            // 
            // btnSua
            // 
            btnSua.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSua.ForeColor = SystemColors.InactiveCaptionText;
            btnSua.Location = new Point(196, 204);
            btnSua.Margin = new Padding(4, 5, 4, 5);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(127, 60);
            btnSua.TabIndex = 62;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = true;
            btnSua.Click += btnSua_Click;
            // 
            // btnXoa
            // 
            btnXoa.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnXoa.ForeColor = SystemColors.InactiveCaptionText;
            btnXoa.Location = new Point(342, 204);
            btnXoa.Margin = new Padding(4, 5, 4, 5);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(127, 60);
            btnXoa.TabIndex = 61;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = true;
            btnXoa.Click += btnXoa_Click;
            // 
            // btnLuu
            // 
            btnLuu.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLuu.ForeColor = SystemColors.InactiveCaptionText;
            btnLuu.Location = new Point(1071, 759);
            btnLuu.Margin = new Padding(4, 5, 4, 5);
            btnLuu.Name = "btnLuu";
            btnLuu.Size = new Size(127, 60);
            btnLuu.TabIndex = 63;
            btnLuu.Text = "Lưu";
            btnLuu.UseVisualStyleBackColor = true;
            btnLuu.Click += btnLuu_Click;
            // 
            // btnThem
            // 
            btnThem.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnThem.ForeColor = SystemColors.InactiveCaptionText;
            btnThem.Location = new Point(49, 204);
            btnThem.Margin = new Padding(4, 5, 4, 5);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(127, 60);
            btnThem.TabIndex = 60;
            btnThem.Text = "Thêm";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnThem_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = SystemColors.ControlText;
            label9.Location = new Point(49, 297);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(191, 24);
            label9.TabIndex = 65;
            label9.Text = "Danh sách bài tập";
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "Môn học";
            columnHeader1.Width = 100;
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "Tiêu đề";
            columnHeader2.Width = 300;
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "Ngày giao";
            columnHeader3.Width = 150;
            // 
            // lvHomeworklist
            // 
            lvHomeworklist.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2, columnHeader3 });
            lvHomeworklist.FullRowSelect = true;
            lvHomeworklist.Location = new Point(49, 324);
            lvHomeworklist.Name = "lvHomeworklist";
            lvHomeworklist.Size = new Size(583, 427);
            lvHomeworklist.TabIndex = 66;
            lvHomeworklist.UseCompatibleStateImageBehavior = false;
            lvHomeworklist.View = View.Details;
            lvHomeworklist.SelectedIndexChanged += lvHomeworklist_SelectedIndexChanged;
            // 
            // Homework
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1388, 826);
            Controls.Add(lvHomeworklist);
            Controls.Add(label9);
            Controls.Add(btnHuy);
            Controls.Add(btnSua);
            Controls.Add(btnXoa);
            Controls.Add(btnLuu);
            Controls.Add(btnThem);
            Controls.Add(label8);
            Controls.Add(rtbDescription);
            Controls.Add(dtpDueDate);
            Controls.Add(dtpAssignDate);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(txtTitle);
            Controls.Add(label4);
            Controls.Add(cboTeacher);
            Controls.Add(label2);
            Controls.Add(cboSubject);
            Controls.Add(cboClass);
            Controls.Add(label1);
            Controls.Add(label3);
            Name = "Homework";
            Text = "Homework";
            ResumeLayout(false);
            PerformLayout();
        }

        private void label5_Click(object sender, EventArgs e)
        {
        }

        #endregion

        private Label label3;
        private Label label1;
        private ComboBox cboClass;
        private ComboBox cboSubject;
        private Label label2;
        private ComboBox cboTeacher;
        private Label label4;
        private TextBox txtTitle;
        private Label label5;
        private Label label6;
        private Label label7;
        private DateTimePicker dtpAssignDate;
        private DateTimePicker dtpDueDate;
        private RichTextBox rtbDescription;
        private Label label8;
        private Button btnHuy;
        private Button btnSua;
        private Button btnXoa;
        private Button btnLuu;
        private Button btnThem;
        private Label label9;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ListView lvHomeworklist;
    }
}