﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace StudentManagement
{
    public partial class Class : Form
    {
        private readonly string connectionString = @"Data Source=localhost;Initial Catalog=studentDb;Persist Security Info=True;User ID=sa;Password=123456";
        private int selectedClassId = -1;

        public Class()
        {
            InitializeComponent();
            LoadTeachers();
            LoadClasses();
        }

        private void LoadTeachers()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT id, tenGV FROM teacher";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                cboTeacher.DataSource = dt;
                cboTeacher.DisplayMember = "tenGV";
                cboTeacher.ValueMember = "id";
                cboTeacher.SelectedIndex = -1;
            }
        }

        private void LoadClasses()
        {
            lvClassList.Items.Clear();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = @"
                    SELECT c.ClassID, c.ClassName, t.tenGV
                    FROM Classes c
                    LEFT JOIN teacher t ON c.TeacherID = t.id";

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ListViewItem item = new ListViewItem(reader["ClassName"].ToString());
                    item.SubItems.Add(reader["tenGV"]?.ToString() ?? ""); // Tránh lỗi NULL
                    item.Tag = reader["ClassID"];
                    lvClassList.Items.Add(item);
                }
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            ClearInputs();
            selectedClassId = -1;
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            string className = txtClassName.Text.Trim();
            string description = txtDescription.Text.Trim();

            if (string.IsNullOrEmpty(className) || cboTeacher.SelectedIndex == -1)
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin lớp và chọn giáo viên.");
                return;
            }

            int teacherId = (int)cboTeacher.SelectedValue;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd;
                if (selectedClassId == -1)
                {
                    cmd = new SqlCommand("INSERT INTO Classes (ClassName, TeacherID, Description) VALUES (@name, @teacher, @desc)", conn);
                }
                else
                {
                    cmd = new SqlCommand("UPDATE Classes SET ClassName = @name, TeacherID = @teacher, Description = @desc WHERE ClassID = @id", conn);
                    cmd.Parameters.AddWithValue("@id", selectedClassId);
                }

                cmd.Parameters.AddWithValue("@name", className);
                cmd.Parameters.AddWithValue("@teacher", teacherId);
                cmd.Parameters.AddWithValue("@desc", description);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Đã lưu lớp thành công.");
                LoadClasses();
                ClearInputs();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (selectedClassId == -1)
            {
                MessageBox.Show("Vui lòng chọn lớp để xóa.");
                return;
            }

            var result = MessageBox.Show("Bạn có chắc chắn muốn xóa lớp này không?", "Xác nhận", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM Classes WHERE ClassID = @id", conn);
                    cmd.Parameters.AddWithValue("@id", selectedClassId);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Đã xóa lớp.");
                    LoadClasses();
                    ClearInputs();
                }
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (lvClassList.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = lvClassList.SelectedItems[0];
                selectedClassId = Convert.ToInt32(selectedItem.Tag);

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT * FROM Classes WHERE ClassID = @id", conn);
                    cmd.Parameters.AddWithValue("@id", selectedClassId);
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        txtClassName.Text = reader["ClassName"].ToString();
                        txtDescription.Text = reader["Description"].ToString();
                        cboTeacher.SelectedValue = reader["TeacherID"];
                    }
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn lớp để sửa.");
            }
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            ClearInputs();
            selectedClassId = -1;
        }

        private void ClearInputs()
        {
            txtClassName.Clear();
            txtDescription.Clear();
            cboTeacher.SelectedIndex = -1;
        }

        private void btnViewClass_Click(object sender, EventArgs e)
        {
            if (lvClassList.SelectedItems.Count > 0)
            {
                int classId = Convert.ToInt32(lvClassList.SelectedItems[0].Tag);

                AppState.CurrentClassId = classId;
                ClassDetail detailForm = new ClassDetail(classId);
                detailForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn lớp để xem chi tiết.");
            }
        }
    }

    public static class AppState
    {
        public static int CurrentClassId { get; set; }
    }
}
