﻿namespace StudentManagement
{
    partial class Student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            dataGridView1 = new DataGridView();
            txtSearch = new TextBox();
            btnSearch = new Button();
            panel2 = new Panel();
            cmbClass = new ComboBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            Class = new Label();
            label1 = new Label();
            cmbGender = new ComboBox();
            dtpDOB = new DateTimePicker();
            txtEmail = new TextBox();
            txtPhone = new TextBox();
            txtName = new TextBox();
            btnUpdate = new Button();
            btnDelete = new Button();
            btnAdd = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(dataGridView1);
            panel1.Controls.Add(txtSearch);
            panel1.Controls.Add(btnSearch);
            panel1.Location = new Point(0, 253);
            panel1.Name = "panel1";
            panel1.Size = new Size(1073, 262);
            panel1.TabIndex = 0;
            // 
            // dataGridView1
            // 
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(9, 52);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(1061, 244);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(133, 3);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(496, 27);
            txtSearch.TabIndex = 8;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(12, 3);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(94, 29);
            btnSearch.TabIndex = 3;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(cmbClass);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(Class);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(cmbGender);
            panel2.Controls.Add(dtpDOB);
            panel2.Controls.Add(txtEmail);
            panel2.Controls.Add(txtPhone);
            panel2.Controls.Add(txtName);
            panel2.Controls.Add(btnUpdate);
            panel2.Controls.Add(btnDelete);
            panel2.Controls.Add(btnAdd);
            panel2.Location = new Point(3, 7);
            panel2.Name = "panel2";
            panel2.Size = new Size(1072, 240);
            panel2.TabIndex = 1;
            // 
            // cmbClass
            // 
            cmbClass.FormattingEnabled = true;
            cmbClass.Location = new Point(380, 114);
            cmbClass.Name = "cmbClass";
            cmbClass.Size = new Size(133, 28);
            cmbClass.TabIndex = 18;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Tahoma", 24F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label6.ForeColor = SystemColors.MenuHighlight;
            label6.Location = new Point(355, 21);
            label6.Name = "label6";
            label6.Size = new Size(375, 48);
            label6.TabIndex = 17;
            label6.Text = "Quản Lý Hoc Sinh";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(488, 188);
            label5.Name = "label5";
            label5.Size = new Size(70, 20);
            label5.TabIndex = 16;
            label5.Text = "Birth Day";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.Control;
            label4.Location = new Point(136, 188);
            label4.Name = "label4";
            label4.Size = new Size(46, 20);
            label4.TabIndex = 15;
            label4.Text = "Email";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(772, 122);
            label3.Name = "label3";
            label3.Size = new Size(68, 20);
            label3.TabIndex = 14;
            label3.Text = "Giới Tính";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(524, 116);
            label2.Name = "label2";
            label2.Size = new Size(35, 20);
            label2.TabIndex = 13;
            label2.Text = "SDT";
            // 
            // Class
            // 
            Class.AutoSize = true;
            Class.Location = new Point(340, 121);
            Class.Name = "Class";
            Class.Size = new Size(34, 20);
            Class.TabIndex = 12;
            Class.Text = "Lớp";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.Control;
            label1.Location = new Point(137, 120);
            label1.Name = "label1";
            label1.Size = new Size(32, 20);
            label1.TabIndex = 11;
            label1.Text = "Tên";
            // 
            // cmbGender
            // 
            cmbGender.FormattingEnabled = true;
            cmbGender.Items.AddRange(new object[] { "Nam", "Nữ" });
            cmbGender.Location = new Point(865, 112);
            cmbGender.Name = "cmbGender";
            cmbGender.Size = new Size(151, 28);
            cmbGender.TabIndex = 10;
            cmbGender.SelectedIndexChanged += cmbGender_SelectedIndexChanged;
            // 
            // dtpDOB
            // 
            dtpDOB.Location = new Point(564, 181);
            dtpDOB.Name = "dtpDOB";
            dtpDOB.Size = new Size(250, 27);
            dtpDOB.TabIndex = 9;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(209, 181);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(250, 27);
            txtEmail.TabIndex = 7;
            // 
            // txtPhone
            // 
            txtPhone.Location = new Point(565, 115);
            txtPhone.Name = "txtPhone";
            txtPhone.Size = new Size(165, 27);
            txtPhone.TabIndex = 6;
            txtPhone.TextChanged += txtPhone_TextChanged;
            // 
            // txtName
            // 
            txtName.Location = new Point(209, 113);
            txtName.Name = "txtName";
            txtName.Size = new Size(125, 27);
            txtName.TabIndex = 4;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(9, 183);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(94, 29);
            btnUpdate.TabIndex = 2;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(9, 148);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(94, 29);
            btnDelete.TabIndex = 1;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(9, 113);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(94, 29);
            btnAdd.TabIndex = 0;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // Student
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1073, 572);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "Student";
            Text = "Student";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }


        #endregion

        private Panel panel1;
        private Panel panel2;
        private Button btnAdd;
        private DataGridView dataGridView1;
        private DateTimePicker dtpDOB;
        private TextBox txtSearch;
        private TextBox txtEmail;
        private TextBox txtPhone;
        private TextBox txtName;
        private Button btnSearch;
        private Button btnUpdate;
        private Button btnDelete;
        private ComboBox cmbGender;
        private Label label2;
        private Label Class;
        private Label label1;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label6;
        private ComboBox cmbClass;
    }
}