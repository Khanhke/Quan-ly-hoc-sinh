﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

namespace StudentManagement
{
    public partial class Admin : Form
    {
        private int selectedAccountId = -1;
        private string currentUsername;
        private bool isEditMode = false;
        private string originalHashedPassword = "";
        string connectionString = @"Data Source=localhost;Initial Catalog=studentDb;Persist Security Info=True;User ID=sa;Password=123456;Encrypt=True;Trust Server Certificate=True";

        public Admin(string username)
        {
            InitializeComponent();
            currentUsername = username;
            LoadAccounts();
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            lblWelcome.Text = $"👋 Xin chào, {currentUsername}";
            LoadAccounts();
            setButton(true);
            txtUsername.Enabled = false;
            txtPassword.Enabled = false;
            cboRole.Enabled = false;
            lblWelcome.Enabled = false;
        }

        private void LoadAccounts()
        {
            listViewAccounts.Items.Clear();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM loginTab", conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    ListViewItem item = new ListViewItem(reader["Username"].ToString());
                    item.SubItems.Add(reader["Password"].ToString());
                    item.SubItems.Add(reader["Role"].ToString());
                    item.Tag = reader["id"];
                    listViewAccounts.Items.Add(item);
                }
            }
        }

        void setButton(bool val)
        {
            btnThem.Enabled = val;
            btnXoa.Enabled = val;
            btnSua.Enabled = val;
            btnThoat.Enabled = val;
            btnLuu.Enabled = !val;
            btnHuy.Enabled = !val;
        }

        private void listViewAccounts_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listViewAccounts.SelectedItems.Count > 0)
            {
                var item = listViewAccounts.SelectedItems[0];
                txtUsername.Text = item.SubItems[0].Text;
                txtPassword.Text = "********";
                cboRole.Text = item.SubItems[2].Text;
                selectedAccountId = Convert.ToInt32(item.Tag);
                originalHashedPassword = item.SubItems[1].Text;
                isEditMode = true;
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            ClearInputs();
            isEditMode = false;
            setButton(false);
            txtUsername.Enabled = true;
            txtPassword.Enabled = true;
            cboRole.Enabled = true;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (selectedAccountId == -1)
            {
                MessageBox.Show("❗ Vui lòng chọn tài khoản để sửa.");
                return;
            }
            isEditMode = true;
            setButton(false);
            txtUsername.Enabled = true;
            txtPassword.Enabled = true;
            cboRole.Enabled = true;
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();
            string role = cboRole.Text.Trim();

            if (!ValidateInputs(username, password, role)) return;

            if (isEditMode)
            {
                using (var conn = GetConnection())
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE loginTab SET Username=@u, Password=@p, Role=@r WHERE id=@id", conn);
                    cmd.Parameters.AddWithValue("@u", username);
                    cmd.Parameters.AddWithValue("@p", password); // LƯU TRỰC TIẾP
                    cmd.Parameters.AddWithValue("@r", role);
                    cmd.Parameters.AddWithValue("@id", selectedAccountId);
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("✅ Đã cập nhật tài khoản.");
            }
            else
            {
                if (UsernameExists(username))
                {
                    MessageBox.Show("⚠️ Tên người dùng đã tồn tại.");
                    return;
                }

                using (var conn = GetConnection())
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("INSERT INTO loginTab (Username, Password, Role) VALUES (@u, @p, @r)", conn);
                    cmd.Parameters.AddWithValue("@u", username);
                    cmd.Parameters.AddWithValue("@p", password); // LƯU TRỰC TIẾP
                    cmd.Parameters.AddWithValue("@r", role);
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("✅ Đã thêm tài khoản.");
            }

            LoadAccounts();
            ClearInputs();
            setButton(true);
            txtUsername.Enabled = false;
            txtPassword.Enabled = false;
            cboRole.Enabled = false;
        }


        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (selectedAccountId != -1)
            {
                DialogResult result = MessageBox.Show("Bạn có chắc muốn xóa tài khoản này không?", "Xác nhận", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("DELETE FROM loginTab WHERE id=@id", conn);
                        cmd.Parameters.AddWithValue("@id", selectedAccountId);
                        cmd.ExecuteNonQuery();
                    }

                    LoadAccounts();
                    MessageBox.Show("🗑️ Đã xóa tài khoản.");
                    ClearInputs();
                }
            }
            else
            {
                MessageBox.Show("⚠️ Vui lòng chọn tài khoản cần xóa.");
            }
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            ClearInputs();
            setButton(true);
            txtUsername.Enabled = false;
            txtPassword.Enabled = false;
            cboRole.Enabled = false;
        }

        private void ClearInputs()
        {
            selectedAccountId = -1;
            txtUsername.Clear();
            txtPassword.Clear();
            cboRole.SelectedIndex = -1;
            listViewAccounts.SelectedItems.Clear();
            isEditMode = false;
            originalHashedPassword = "";
        }

        private SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }

        //private string HashPassword(string password)
        //{
        //    using (SHA256 sha256 = SHA256.Create())
        //    {
        //        byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
        //        StringBuilder builder = new StringBuilder();
        //        foreach (byte b in bytes)
        //        {
        //            builder.Append(b.ToString("x2"));
        //        }
        //        return builder.ToString();
        //    }
        //}

        private bool UsernameExists(string username)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM loginTab WHERE Username=@u", conn);
                cmd.Parameters.AddWithValue("@u", username);
                int count = (int)cmd.ExecuteScalar();
                return count > 0;
            }
        }

        private bool ValidateInputs(string username, string password, string role)
        {
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(role))
            {
                MessageBox.Show("❗ Vui lòng điền đầy đủ thông tin.");
                return false;
            }
            return true;
        }
    }
}
