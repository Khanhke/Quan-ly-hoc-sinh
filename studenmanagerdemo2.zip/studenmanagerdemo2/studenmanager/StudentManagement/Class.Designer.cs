﻿
namespace StudentManagement
{
    partial class Class
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtClassName = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label5 = new Label();
            cboTeacher = new ComboBox();
            txtDescription = new TextBox();
            lvClassList = new ListView();
            btnViewClass = new Button();
            btnHuy = new Button();
            btnSua = new Button();
            btnXoa = new Button();
            btnLuu = new Button();
            btnThem = new Button();
            txtSearch = new TextBox();
            btnSearch = new Button();
            label4 = new Label();
            label6 = new Label();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Tahoma", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.MenuHighlight;
            label1.Location = new Point(13, 9);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(354, 48);
            label1.TabIndex = 40;
            label1.Text = "Quản Lý Lớp học";
            // 
            // txtClassName
            // 
            txtClassName.Location = new Point(157, 76);
            txtClassName.Name = "txtClassName";
            txtClassName.Size = new Size(382, 27);
            txtClassName.TabIndex = 41;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(90, 83);
            label2.Name = "label2";
            label2.Size = new Size(0, 20);
            label2.TabIndex = 42;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ControlText;
            label3.Location = new Point(39, 76);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(89, 24);
            label3.TabIndex = 43;
            label3.Text = "Tên Lớp";


            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.ControlText;
            label5.Location = new Point(39, 133);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(216, 24);
            label5.TabIndex = 44;
            label5.Text = "Giáo viên chủ nhiệm";

            // 
            // cboTeacher
            // 
            cboTeacher.FormattingEnabled = true;
            cboTeacher.Location = new Point(287, 134);
            cboTeacher.Name = "cboTeacher";
            cboTeacher.Size = new Size(252, 28);
            cboTeacher.TabIndex = 45;
            cboTeacher.SelectedIndexChanged += cboTeacher_SelectedIndexChanged;
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(39, 227);
            txtDescription.Multiline = true;
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(500, 97);
            txtDescription.TabIndex = 46;
            // 
            // lvClassList
            // 
            lvClassList.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2 });
            lvClassList.Location = new Point(647, 148);
            lvClassList.Name = "lvClassList";
            lvClassList.Size = new Size(579, 429);
            lvClassList.TabIndex = 47;
            lvClassList.UseCompatibleStateImageBehavior = false;
            lvClassList.View = View.Details;
            lvClassList.FullRowSelect = true;
            // 
            // btnViewClass
            // 
            btnViewClass.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnViewClass.ForeColor = SystemColors.InactiveCaptionText;
            btnViewClass.Location = new Point(412, 453);
            btnViewClass.Margin = new Padding(4, 5, 4, 5);
            btnViewClass.Name = "btnViewClass";
            btnViewClass.Size = new Size(127, 60);
            btnViewClass.TabIndex = 11;
            btnViewClass.Text = "Xem Lớp";
            btnViewClass.UseVisualStyleBackColor = true;
            // 
            // btnHuy
            // 
            btnHuy.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnHuy.ForeColor = SystemColors.InactiveCaptionText;
            btnHuy.Location = new Point(221, 453);
            btnHuy.Margin = new Padding(4, 5, 4, 5);
            btnHuy.Name = "btnHuy";
            btnHuy.Size = new Size(127, 60);
            btnHuy.TabIndex = 10;
            btnHuy.Text = "Hủy";
            btnHuy.UseVisualStyleBackColor = true;
            btnHuy.Click += btnHuy_Click;
            // 
            // btnSua
            // 
            btnSua.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSua.ForeColor = SystemColors.InactiveCaptionText;
            btnSua.Location = new Point(221, 371);
            btnSua.Margin = new Padding(4, 5, 4, 5);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(127, 60);
            btnSua.TabIndex = 8;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = true;
            btnSua.Click += btnSua_Click;
            // 
            // btnXoa
            // 
            btnXoa.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnXoa.ForeColor = SystemColors.InactiveCaptionText;
            btnXoa.Location = new Point(412, 371);
            btnXoa.Margin = new Padding(4, 5, 4, 5);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(127, 60);
            btnXoa.TabIndex = 7;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = true;
            btnXoa.Click += new EventHandler(btnXoa_Click);
            // 
            // btnLuu
            // 
            btnLuu.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLuu.ForeColor = SystemColors.InactiveCaptionText;
            btnLuu.Location = new Point(39, 453);
            btnLuu.Margin = new Padding(4, 5, 4, 5);
            btnLuu.Name = "btnLuu";
            btnLuu.Size = new Size(127, 60);
            btnLuu.TabIndex = 9;
            btnLuu.Text = "Lưu";
            btnLuu.UseVisualStyleBackColor = true;
            btnLuu.Click += btnLuu_Click;
            // 
            // btnThem
            // 
            btnThem.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnThem.ForeColor = SystemColors.InactiveCaptionText;
            btnThem.Location = new Point(39, 371);
            btnThem.Margin = new Padding(4, 5, 4, 5);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(127, 60);
            btnThem.TabIndex = 6;
            btnThem.Text = "Thêm";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnThem_Click; 
           
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(647, 76);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(387, 27);
            txtSearch.TabIndex = 48;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(1085, 74);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(130, 29);
            btnSearch.TabIndex = 49;
            btnSearch.Text = "Tìm kiếm";
            btnSearch.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(42, 194);
            label4.Name = "label4";
            label4.Size = new Size(48, 20);
            label4.TabIndex = 50;
            label4.Text = "Mô tả";
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(647, 125);
            label6.Name = "label6";
            label6.Size = new Size(103, 20);
            label6.TabIndex = 51;
            label6.Text = "Danh sách lớp";
         
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "Lớp";
            columnHeader1.Width = 100;
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "Giáo viên chủ nhiệm";
            columnHeader2.Width = 400;
            // 
            // Class
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1255, 603);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(btnSearch);
            Controls.Add(txtSearch);
            Controls.Add(btnThem);
            Controls.Add(btnHuy);
            Controls.Add(btnViewClass);
            Controls.Add(btnLuu);
            Controls.Add(btnXoa);
            Controls.Add(lvClassList);
            Controls.Add(btnSua);
            Controls.Add(txtDescription);
            Controls.Add(cboTeacher);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtClassName);
            Controls.Add(label1);
            Name = "Class";
            Text = "Class";
            ResumeLayout(false);
            PerformLayout();
            //
            lvClassList.SelectedIndexChanged += lvClassList_SelectedIndexChanged;
            btnViewClass.Click += btnViewClass_Click;
            btnSearch.Click += btnSearch_Click;

        }



        private void cboTeacher_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
       

        private void btnSearch_Click(object sender, EventArgs e)
        {
            // TODO: Xử lý tìm kiếm lớp
        }

        private void lvClassList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvClassList.SelectedItems.Count > 0)
            {
                var selectedItem = lvClassList.SelectedItems[0];
                txtClassName.Text = selectedItem.SubItems[0].Text;
                cboTeacher.Text = selectedItem.SubItems[1].Text;
                // Nếu có thêm cột mô tả thì gán mô tả vào txtDescription
            }
        }
        //
       




        #endregion

        private Label label1;
        private TextBox txtClassName;
        private Label label2;
        private Label label3;
        private Label label5;
        private ComboBox cboTeacher;
        private TextBox txtDescription;
        private ListView lvClassList;
        private Button btnHuy;
        private Button btnXoa;
        private Button btnLuu;
        private Button btnThem;
        private Button btnViewClass;
        private Button btnSua;
        private TextBox txtSearch;
        private Button btnSearch;
        private Label label4;
        private Label label6;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
    }
}