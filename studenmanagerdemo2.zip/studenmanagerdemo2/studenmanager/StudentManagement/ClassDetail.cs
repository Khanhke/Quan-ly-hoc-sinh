﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace StudentManagement
{
    public partial class ClassDetail : Form
    {
        private int classId;
        private string connectionString = @"Data Source=localhost;Initial Catalog=studentDb;Persist Security Info=True;User ID=sa;Password=123456";

        public ClassDetail(int selectedClassId)
        {
            InitializeComponent();
            classId = selectedClassId;
        }

        private void ClassDetail_Load(object sender, EventArgs e)
        {
            LoadClassInfo();
            LoadStudentsInClass();
        }

        private void LoadClassInfo()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"
            SELECT C.ClassName, T.tenGV AS TeacherName
            FROM Classes C
            LEFT JOIN teacher T ON C.TeacherID = T.id
            WHERE C.ClassID = @ClassId";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ClassId", classId); // classId là biến được truyền vào từ bên ngoài

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtClass.Text = reader["ClassName"].ToString();
                    txtTeacher.Text = reader["TeacherName"].ToString();
                }
                conn.Close();
            }
        }


        private void LoadStudentsInClass()
        {
            lvStudentsInClass.Items.Clear();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"
                    SELECT FullName, ClassName, DateOfBirth, Gender, PhoneNumber, Email
                    FROM Students
                    WHERE ClassId = @ClassId";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ClassId", classId);

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ListViewItem item = new ListViewItem(reader["FullName"].ToString());
                    item.SubItems.Add(reader["ClassName"].ToString());
                    item.SubItems.Add(Convert.ToDateTime(reader["DateOfBirth"]).ToString("dd/MM/yyyy"));
                    item.SubItems.Add(reader["Gender"].ToString());
                    item.SubItems.Add(reader["PhoneNumber"].ToString());
                    item.SubItems.Add(reader["Email"].ToString());

                    lvStudentsInClass.Items.Add(item);
                }

                conn.Close();
            }
        }

        private void btnAssignHomework_Click(object sender, EventArgs e)
        {
            string className = txtClass.Text; 
            Homework homeworkForm = new Homework(className); // Truyền tên lớp vào constructor của Homework
            homeworkForm.ShowDialog(); 
        }

    }
}
