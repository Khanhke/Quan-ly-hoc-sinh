﻿using Microsoft.Data.SqlClient;
using System.Data;


namespace StudentManagement
{
    public partial class Student : Form
    {

        string connectionString = @"Data Source=localhost;Initial Catalog=studentDb;Persist Security Info=True;User ID=sa;Password=123456;Encrypt=True;Trust Server Certificate=True";
        public Student()
        {
            InitializeComponent();
            LoadStudents();
            LoadClasses();  // Load Class data into ComboBox
        }
        private void LoadClasses()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT ClassID, ClassName FROM Classes";  // Load Class data
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                // Bind Class data to ComboBox
                cmbClass.DataSource = dt;
                cmbClass.DisplayMember = "ClassName";
                cmbClass.ValueMember = "ClassID";
            }
        }
        private void LoadStudents()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT s.StudentID, s.FullName, s.DateOfBirth, s.Gender, s.PhoneNumber, s.Email, s.ClassID, s.ClassName " +
                               "FROM Students s";  // No need for a JOIN anymore

                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                // Bind DataGridView to the DataTable
                dataGridView1.DataSource = dt;

                // Hide ClassID column if you don't want to display it
                dataGridView1.Columns["ClassID"].Visible = false;
            }
        }

        private void txtPhone_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Students (FullName, ClassID, ClassName, DateOfBirth, Gender, PhoneNumber, Email) " +
                               "VALUES (@FullName, @ClassID, @ClassName, @DOB, @Gender, @Phone, @Email)";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@FullName", txtName.Text);
                cmd.Parameters.AddWithValue("@ClassID", cmbClass.SelectedValue);  // ClassID from ComboBox
                cmd.Parameters.AddWithValue("@ClassName", cmbClass.Text);  // ClassName from ComboBox text
                cmd.Parameters.AddWithValue("@DOB", dtpDOB.Value);  // Date of Birth
                cmd.Parameters.AddWithValue("@Gender", cmbGender.Text);  // Gender
                cmd.Parameters.AddWithValue("@Phone", txtPhone.Text);  // Phone Number
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text);  // Email

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Đã thêm học sinh mới!");
                LoadStudents();  // Refresh the list after adding a student
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null) return;
            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["StudentID"].Value);

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "UPDATE Students SET FullName=@FullName, ClassID=@ClassID, ClassName=@ClassName, DateOfBirth=@DOB, " +
                               "Gender=@Gender, PhoneNumber=@Phone, Email=@Email WHERE StudentID=@ID";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@ID", id);
                cmd.Parameters.AddWithValue("@FullName", txtName.Text);
                cmd.Parameters.AddWithValue("@ClassID", cmbClass.SelectedValue);  // ClassID from ComboBox
                cmd.Parameters.AddWithValue("@ClassName", cmbClass.Text);  // ClassName from ComboBox
                cmd.Parameters.AddWithValue("@DOB", dtpDOB.Value);
                cmd.Parameters.AddWithValue("@Gender", cmbGender.Text);
                cmd.Parameters.AddWithValue("@Phone", txtPhone.Text);
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Đã cập nhật!");
                LoadStudents();  // Refresh the list after update
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null) return;
            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["StudentID"].Value);

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Students WHERE StudentID=@ID";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@ID", id);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Đã xóa!");
                LoadStudents();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Students WHERE FullName LIKE @keyword";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@keyword", "%" + txtSearch.Text + "%");

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Debugging to check the column names
                foreach (DataGridViewColumn column in dataGridView1.Columns)
                {
                    Console.WriteLine(column.Name);  // Print column name to debug
                }
                

                txtName.Text = row.Cells["FullName"].Value.ToString();
                cmbClass.SelectedValue = row.Cells["ClassID"].Value;  // Set ComboBox value to ClassID
                dtpDOB.Value = Convert.ToDateTime(row.Cells["DateOfBirth"].Value);
                cmbGender.Text = row.Cells["Gender"].Value.ToString();
                txtPhone.Text = row.Cells["PhoneNumber"].Value.ToString();
                txtEmail.Text = row.Cells["Email"].Value.ToString();dataGridView1.Columns["ClassID"].Visible = false;
            }
            

        }


        private void cmbGender_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
