﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudentManagement
{
    public partial class Teacher : Form
    {
        string connectionString = @"Data Source=localhost;Initial Catalog=studentDb;Persist Security Info=True;User ID=sa;Password=123456";
        bool isAdding = false;
        private string currentUsername;

        // Constructor mặc định
        public Teacher()
        {
            InitializeComponent();
            LoadTeachers();
        }

        public Teacher(string someValue, string username)
        {
            InitializeComponent();
            LoadTeachers();

            txtidGv.Text = someValue;
            currentUsername = username;
        }

        void LoadTeachers()
        {
            lsvGiaoVien.Items.Clear();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT id, tenGV, sdt, email, diachi FROM teacher";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    ListViewItem item = new ListViewItem(reader["id"].ToString());
                    item.SubItems.Add(reader["tenGV"].ToString());
                    item.SubItems.Add(reader["sdt"].ToString());
                    item.SubItems.Add(reader["email"].ToString());
                    item.SubItems.Add(reader["diachi"].ToString());
                    lsvGiaoVien.Items.Add(item);
                }
            }
            txtidGv.Enabled = false;
        }

        void ClearInputs()
        {
            txtidGv.Clear();
            txttenGv.Clear();
            txtsdt.Clear();
            txtEmail.Clear();
            txtdiachi.Clear();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            isAdding = true;
            ClearInputs();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (lsvGiaoVien.SelectedItems.Count == 0) return;

            string id = lsvGiaoVien.SelectedItems[0].SubItems[0].Text;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "DELETE FROM teacher WHERE id = @id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
            }
            LoadTeachers();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (lsvGiaoVien.SelectedItems.Count == 0) return;
            isAdding = false;

            ListViewItem selected = lsvGiaoVien.SelectedItems[0];
            txtidGv.Text = selected.SubItems[0].Text;
            txttenGv.Text = selected.SubItems[1].Text;
            txtsdt.Text = selected.SubItems[2].Text;
            txtEmail.Text = selected.SubItems[3].Text;
            txtdiachi.Text = selected.SubItems[4].Text;
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd;

                if (isAdding)
                {
                    string query = "INSERT INTO teacher (tenGV, sdt, email, diachi) VALUES (@ten, @sdt, @email, @diachi)";
                    cmd = new SqlCommand(query, conn);
                }
                else
                {
                    string query = "UPDATE teacher SET tenGV=@ten, sdt=@sdt, email=@email, diachi=@diachi WHERE id=@id";
                    cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id", txtidGv.Text);
                }

                cmd.Parameters.AddWithValue("@ten", txttenGv.Text);
                cmd.Parameters.AddWithValue("@sdt", txtsdt.Text);
                cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@diachi", txtdiachi.Text);
                cmd.ExecuteNonQuery();
            }
            LoadTeachers();
        }


        private void btnHuy_Click(object sender, EventArgs e)
        {
            ClearInputs();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txttenGv_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

