﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace StudentManagement
{
    public partial class Homework : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=localhost;Initial Catalog=studentDb;Persist Security Info=True;User ID=sa;Password=123456");
        SqlCommand cmd;
        SqlDataAdapter adapter;
        DataTable dt;

        bool isAdding = false;

        // Constructor 
        public Homework(string className)
        {
            InitializeComponent();
            LoadComboboxes();
            LoadHomework();
            SetClassName(className); // Gán tên lớp vào ComboBox
        }

        // Gán tên lớp vào ComboBox
        private void SetClassName(string className)
        {
            // seach to ComboBox 
            foreach (DataRow row in ((DataTable)cboClass.DataSource).Rows)
            {
                if (row["ClassName"].ToString() == className)
                {
                    cboClass.SelectedValue = row["ClassID"];
                    break;
                }
            }
        }

        //  ComboBox
        private void LoadComboboxes()
        {
            // class
            adapter = new SqlDataAdapter("SELECT ClassID, ClassName FROM Classes", conn);
            dt = new DataTable();
            adapter.Fill(dt);
            cboClass.DataSource = dt;
            cboClass.DisplayMember = "ClassName";
            cboClass.ValueMember = "ClassID";

            // subject
            adapter = new SqlDataAdapter("SELECT SubjectID, SubjectName FROM Subjects", conn);
            dt = new DataTable();
            adapter.Fill(dt);
            cboSubject.DataSource = dt;
            cboSubject.DisplayMember = "SubjectName";
            cboSubject.ValueMember = "SubjectID";

            // Teacher
            adapter = new SqlDataAdapter("SELECT id, tenGV FROM Teacher", conn);
            dt = new DataTable();
            adapter.Fill(dt);
            cboTeacher.DataSource = dt;
            cboTeacher.DisplayMember = "tenGV";
            cboTeacher.ValueMember = "id";
        }

        // Tải danh sách bài tập vào ListView
        private void LoadHomework()
        {
            lvHomeworklist.Items.Clear();
            conn.Open();

            SqlCommand cmd = new SqlCommand(
                "SELECT H.HomeworkID, H.Title, H.AssignDate, S.SubjectName " +
                "FROM Homework H " +
                "JOIN Subjects S ON H.SubjectID = S.SubjectID", conn);

            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                ListViewItem item = new ListViewItem(dr["SubjectName"].ToString());
                item.SubItems.Add(dr["Title"].ToString());
                item.SubItems.Add(Convert.ToDateTime(dr["AssignDate"]).ToString("dd/MM/yyyy"));

                // Lưu HomeworkID vào Tag
                item.Tag = dr["HomeworkID"];

                lvHomeworklist.Items.Add(item);
            }

            conn.Close();
        }

        private void lvHomeworklist_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvHomeworklist.SelectedItems.Count == 0) return;

            ListViewItem item = lvHomeworklist.SelectedItems[0];

            // Lấy HomeworkID từ Tag
            int homeworkID = (int)item.Tag;

            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Homework WHERE HomeworkID = @id", conn);
            cmd.Parameters.AddWithValue("@id", homeworkID);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                cboClass.SelectedValue = dr["ClassID"];
                cboSubject.SelectedValue = dr["SubjectID"];
                cboTeacher.SelectedValue = dr["TeacherID"];
                txtTitle.Text = dr["Title"].ToString();
                rtbDescription.Text = dr["Description"].ToString();
                dtpAssignDate.Value = Convert.ToDateTime(dr["AssignDate"]);
                dtpDueDate.Value = Convert.ToDateTime(dr["DueDate"]);
            }
            conn.Close();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            isAdding = true;
            ClearFields();
            EnableFields(true);
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (lvHomeworklist.SelectedItems.Count == 0) return;
            isAdding = false;
            EnableFields(true);
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (lvHomeworklist.SelectedItems.Count == 0) return;

            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa bài tập này không?", "Xác nhận", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                int homeworkID = int.Parse(lvHomeworklist.SelectedItems[0].SubItems[0].Text);

                conn.Open();
                cmd = new SqlCommand("DELETE FROM Homework WHERE HomeworkID=@id", conn);
                cmd.Parameters.AddWithValue("@id", homeworkID);
                cmd.ExecuteNonQuery();
                conn.Close();

                LoadHomework();
                ClearFields();
            }
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            int classID = (int)cboClass.SelectedValue;
            int subjectID = (int)cboSubject.SelectedValue;
            int teacherID = (int)cboTeacher.SelectedValue;
            string title = txtTitle.Text;
            string description = rtbDescription.Text;
            DateTime assignDate = dtpAssignDate.Value;
            DateTime dueDate = dtpDueDate.Value;

            conn.Open();
            string query;

            if (isAdding)
            {
                // Insert new Homework
                query = "INSERT INTO Homework(ClassID, SubjectID, TeacherID, Title, Description, AssignDate, DueDate) " +
                        "VALUES(@class, @subject, @teacher, @title, @desc, @assign, @due)";
            }
            else
            {
                // Update existing Homework
                int homeworkID = (int)lvHomeworklist.SelectedItems[0].Tag; // Corrected to get HomeworkID from Tag
                query = "UPDATE Homework SET ClassID=@class, SubjectID=@subject, TeacherID=@teacher, Title=@title, " +
                        "Description=@desc, AssignDate=@assign, DueDate=@due WHERE HomeworkID=@id";
            }

            cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@class", classID);
            cmd.Parameters.AddWithValue("@subject", subjectID);
            cmd.Parameters.AddWithValue("@teacher", teacherID);
            cmd.Parameters.AddWithValue("@title", title);
            cmd.Parameters.AddWithValue("@desc", description);
            cmd.Parameters.AddWithValue("@assign", assignDate);
            cmd.Parameters.AddWithValue("@due", dueDate);

            if (!isAdding)
            {
                int homeworkID = (int)lvHomeworklist.SelectedItems[0].Tag; // Get HomeworkID from ListView's Tag
                cmd.Parameters.AddWithValue("@id", homeworkID);
            }

            cmd.ExecuteNonQuery();
            conn.Close();

            LoadHomework();
            ClearFields();
            EnableFields(false);
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            ClearFields();
            EnableFields(false);
        }

        private void ClearFields()
        {
            cboClass.SelectedIndex = 0;
            cboSubject.SelectedIndex = 0;
            cboTeacher.SelectedIndex = 0;
            txtTitle.Clear();
            rtbDescription.Clear();
            dtpAssignDate.Value = DateTime.Now;
            dtpDueDate.Value = DateTime.Now;
        }

        private void EnableFields(bool enable)
        {
            cboClass.Enabled = enable;
            cboSubject.Enabled = enable;
            cboTeacher.Enabled = enable;
            txtTitle.Enabled = enable;
            rtbDescription.Enabled = enable;
            dtpAssignDate.Enabled = enable;
            dtpDueDate.Enabled = enable;
        }
    }
}
